#include "Color.h"

Dye::Dye(Color color):color(color)
{
    
}